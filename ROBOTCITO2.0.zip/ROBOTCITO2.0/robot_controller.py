class RobotController:
    def __init__(self, modelo, vista):
        self.modelo = modelo
        self.vista = vista
    
    def ejecutar(self):
        while True:
            self.vista.mostrar_menu()
            opcion = self.vista.obtener_opcion_usuario()
            
            if opcion == "1":
                self.mover_elevacion()
            elif opcion == "2":
                self.mover_rotacion()
            elif opcion == "3":
                self.mover_longitud()
            elif opcion == "4":
                self.detener_movimiento()
            elif opcion == "5":
                break
            else:
                self.vista.mostrar_error("Opción inválida")

    def mover_elevacion(self):
        elevacion, _, _ = self.vista.obtener_valores_movimiento()
        self.modelo.mover_elevacion(elevacion)
        self.vista.mostrar_mensaje("Elevación movida a {}".format(elevacion))
    
    def mover_rotacion(self):
        _, rotacion, _ = self.vista.obtener_valores_movimiento()
        self.modelo.mover_rotacion(rotacion)
        self.vista.mostrar_mensaje("Rotación movida a {}".format(rotacion))
    
    def mover_longitud(self):
        _, _, longitud = self.vista.obtener_valores_movimiento()
        self.modelo.mover_longitud(longitud)
        self.vista.mostrar_mensaje("Longitud movida a {}".format(longitud))
    
    def detener_movimiento(self):
        self.modelo.detener_movimiento()
        self.vista.mostrar_mensaje("Movimiento detenido")
