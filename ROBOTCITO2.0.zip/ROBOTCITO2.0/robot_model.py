class RobotModel:
    def __init__(self):
        self.elevacion_actual = 0
        self.rotacion_actual = 0
        self.longitud_actual = 0
        self.movimiento_en_curso = False

    def mover_elevacion(self, elevacion):
        if self.movimiento_en_curso:
            raise Exception("El brazo robótico ya está en movimiento.")
        self.elevacion_actual = elevacion
        self.movimiento_en_curso = True

    def mover_rotacion(self, rotacion):
        if self.movimiento_en_curso:
            raise Exception("El brazo robótico ya está en movimiento.")
        self.rotacion_actual = rotacion
        self.movimiento_en_curso = True

    def mover_longitud(self, longitud):
        if self.movimiento_en_curso:
            raise Exception("El brazo robótico ya está en movimiento.")
        self.longitud_actual = longitud
        self.movimiento_en_curso = True

    def detener_movimiento(self):
        self.movimiento_en_curso = False
