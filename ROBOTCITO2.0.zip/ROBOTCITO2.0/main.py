from robot_model import RobotModel
from robot_view import RobotView
from robot_controller import RobotController

def main():
    modelo = RobotModel()
    vista = RobotView()
    controlador = RobotController(modelo, vista)
    controlador.ejecutar()

if __name__ == "__main__":
    main()
