# -*- coding: utf-8 -*-
"""
Created on Mon Apr 29 22:31:25 2024

@author: User
"""

class RobotView:
    def mostrar_menu(self):
        print("---- Menú ----")
        print("1. Mover elevación")
        print("2. Mover rotación")
        print("3. Mover longitud")
        print("4. Detener movimiento")
        print("5. Salir")
    def obtener_opcion_usuario(self):
        opcion = input("Seleccione una opción: ")
        return opcion
    def obtener_valores_movimiento(self):
        elevacion = float(input("Ingrese el valor de elevación: "))
        rotacion = float(input("Ingrese el valor de rotación: "))
        longitud = float(input("Ingrese el valor de longitud: "))
        return elevacion, rotacion, longitud
    def mostrar_mensaje(self, mensaje):
        print(mensaje)
    def mostrar_error(self, error):
        print("Error:", error)
